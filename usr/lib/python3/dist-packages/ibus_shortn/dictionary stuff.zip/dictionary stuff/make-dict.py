# Copyright (c) 2026 - Bastien Jean Quemener <shortn@bastien.live>  (github.com/BastienJeanQuemerRXJ/ibus-shortn)
#
# This file is part of ibus-shortn, the IBus Shortn input method engine, forked from ibus-cangjie.
#
# ibus-shortn is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# ibus-shortn is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with ibus-shortn.  If not, see <http://www.gnu.org/licenses/>.


#add here
#if .json file doesnt exist, look for a .txt file of the same name
#if exists, check to see if it has windows or unix style ending  (\n) instead of (\r\n)
#then check to see if accents in the file, if yes check if they are one character instead of two  (ie nfc accents)
#then convert to json


#this is a debug tool that will write on a txt file called "shortndebug.txt" whatever you ask it to. ie logwrite(the) will write 'the' to shortndebug.txt. however it needs sudo perms and editing files so that's not too appropriate for a public release or something. its uses are still left in the file but commented out in case you are having troubles

def logwrite(the, e=0):
    #except Exception as the
    if e==1:
        the="shortnengine failed because of"+getattr(the, 'message', repr(the))
    the=str(the)
    with open('/home/bastien/Desktop/shortndebug.txt', 'a', encoding='utf-8') as f:
        f.writelines(the)
        
#import languageclassfile which does all the language config stuff 
try:
    from languageclassfile import language  
except Exception as p:
    logwrite(p,e=1)
overarchinglanguage=language.givelanguageanddic("shortn")[0]

def whattodo(action, toadd, langcode):
    #action=="build", action=="add"
    if action=="build":
        
        
    
    
    
    #list of words to add to dictionary
    in_=overarchinglanguage.dictionaryname[:2]+"-list.json"
    #preexisting dictionary to add from
    if action=="build":
        supportdic=None
    else:
        supportdic
#target dictionary to write as
out=overarchinglanguage.dictionaryname
import json
if supportdic!=None:
    with open(supportdic,'r') as dic:
        dicvar=json.load(dic)
else:
    dicvar={"lolcn":["pedophile", "lolicon"]}



vowel=overarchinglanguage.encodedvowel

def generate_shortcut(word):
    global dicvar
    vowc=0
    ret=""
    word=overarchinglanguage.encodingfromoriginal(word)
    for i in word:
        if i in vowel and vowc!=1:
            ret+=i
            vowc+=1
        elif i not in vowel:
            ret+=i
    try:
        dicvar[ret]+=[word]
    except:
        dicvar[ret]=[word]

with open(in_,'r') as poop:
    words=json.load(poop)
for i in words:
    generate_shortcut(i)
with open(out, 'w',) as f:
    json.dump(dicvar, f)
    
