import json
import unicodedata
with open('in.json', 'r', encoding='utf-8') as f:
    data = json.load(f)
def normalize_accents(text):
    if isinstance(text, str):
        return unicodedata.normalize('NFC', text)
    return text
def fix_accents(obj):
    if isinstance(obj, dict):
        return {key: fix_accents(value) for key, value in obj.items()}
    elif isinstance(obj, list):
        return [fix_accents(item) for item in obj]
    elif isinstance(obj, str):
        return normalize_accents(obj)
    else:
        return obj
fixed_data = fix_accents(data)
with open('in_fixed.json', 'w', encoding='utf-8') as f:
    json.dump(fixed_data, f, ensure_ascii=False, indent=2)