#!/bin/bash
if [[ ! -f "en-list.txt" ]]; then
    echo "Error: in.txt not found"
    exit 1
fi
jq -R -s 'split("\n") | map(select(length > 0))' en-list.txt > en-list.json

